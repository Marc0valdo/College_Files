#include "product.h"

int product_int(int *v, int n) {
    int product = 1;
    for (int i = 0; i < n; i++) {
        product *= v[i];
    }
    return product;
}

double product_double(double *v, int n) {
    double product = 1.0;
    for (int i = 0; i < n; i++) {
        product *= v[i];
    }
    return product;
}