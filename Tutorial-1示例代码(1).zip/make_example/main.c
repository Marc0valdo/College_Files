#include "sum.h"
#include "product.h"

int main() {
    int v1[] = {1, 2, 3, 4, 5};
    double v2[] = {1.1, 2.2, 3.3, 4.4, 5.5};
    int n = 5;
    printf("sum_int(v1) = %d\n", sum_int(v1, n));
    printf("sum_double(v2) = %f\n", sum_double(v2, n));
    printf("product_int(v1) = %d\n", product_int(v1, n));
    printf("product_double(v2) = %f\n", product_double(v2, n));
    return 0;
}