#include <stdio.h>
#include <stdlib.h>

int sum_int(int *v, int n);

double sum_double(double *v, int n);