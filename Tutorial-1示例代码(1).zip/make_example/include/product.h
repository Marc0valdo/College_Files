#include <stdio.h>
#include <stdlib.h>

int product_int(int *v, int n);

double product_double(double *v, int n);