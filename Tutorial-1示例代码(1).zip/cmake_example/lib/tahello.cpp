#include <iostream>

void tahello() {
    std::cout << "TA says hello!" << std::endl;
}