#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>

extern void tahello();

int main(int argc, char **argv) {
    int option = 0;
    if (argc == 2)
        option = atoi(argv[1]);

    switch (option) {
        case 0:
            tahello();
            break;
        case 1:
            std::cout << "Hello Network Hello PKU\n";
            break;
        default:
            std::cerr << "No such option\n";
            return 1;
    }
    return 0;
}
